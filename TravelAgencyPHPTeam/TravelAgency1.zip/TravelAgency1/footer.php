<footer class="container">
<p class="float-right btn btn-light btn-sm"><a href="#"><i class="fas fa-arrow-up"></i> Back to top</a></p>
<p>&copy; Copyright 2018 Travel Experts &middot;
  <i class="fab fa-twitter-square"></i>   <i class="fab fa-instagram"></i>  <i class="fab fa-facebook"></i> </p>
</footer>
</main>

    </main>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="../../assets/js/vendor/popper.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>
  </body>
</html>